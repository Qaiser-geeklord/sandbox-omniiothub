# from asyncio.windows_events import NULL
from cmath import log
import logging
from pickle import FALSE
from sqlite3 import Cursor

import uuid
from functools import partial
# from pyspark.sql import SparkSession
# from pyspark.sql.types import StructType, StructField, IntegerType, LongType, StringType, FloatType
import azure.functions as func
from azure.eventhub import EventHubProducerClient
from azure.eventhub import EventData
from io import StringIO
from azure.storage.blob import BlobClient
import json
import time
import pandas as pd
import pytz
import re
import numbers
import pyodbc
import datetime
import requests
import copy
import os
import uuid
from datetime import date, timedelta
from datetime import datetime as dt
from collections import OrderedDict
from azure.kusto.data import KustoClient, KustoConnectionStringBuilder
# from azure.kusto.data.exceptions import KustoServiceError
from azure.kusto.data.helpers import dataframe_from_result_table
from azure.cli.core import get_default_cli
import sys
pd.options.mode.chained_assignment = None  # default='warn'

logger = logging.getLogger('abdullah')
logger.setLevel(logging.INFO)
sh = logging.StreamHandler()
sh.setLevel(logging.INFO)
logger.addHandler(sh)

#ADX APP Credentials
AAD_TENANT_ID = os.environ["AAD_Tenant_Id"]
client_id = os.environ["Client_Id"]
client_secret = os.environ["Client_Secret"]

dict_hh = {}
dict_ll = {}

def get_site_name(cnxn, site_id):
    sql = "SELECT AutomationTableName FROM Plant_Site WHERE Site_Id = '"+str(site_id)+"'"
    temp_df = pd.read_sql(sql,cnxn)
    site_name = temp_df['AutomationTableName'][0]
    return site_name

#Azure CLI Function
def az_cli (args_str):
    args = args_str.split()
    cli = get_default_cli()
    # logging.info(args)
    cli.invoke(args)
    if cli.result.result:
        return cli.result.result
    elif cli.result.error:
        logging.info("in raise error")
        raise cli.result.error
    return True

def get_eventhub_connStr(site_name):
    pass


def dataAlarm_to_eventhub(df,conn_str):
    if not df.empty:
        CONNECTION_STR = conn_str
        EVENTHUB_NAME = "dataalarms"
        
        df.dropna(subset = ["Reading_Time"], inplace=True)

        df = df.drop('action_ID', axis=1)
        df.reset_index(drop=True,inplace=True)
        # logging.info(df[['']])
        
        # Without specifying partition_id or partition_key
        # the events will be distributed to available partitions via round-robin.
        try:
            producer = EventHubProducerClient.from_connection_string(conn_str=CONNECTION_STR,eventhub_name=EVENTHUB_NAME)
        except Exception as e:
            raise Exception(str(e))

        try:
            with producer:
                # send_event_data_batch(producer)
            
                event_data_batch = producer.create_batch()
                logging.info("Sending Data to Eventhub")
                for i in df.index:
                    json_string = df.loc[i].to_json()
                    logging.info("JSON STRING VALUES!!!")
                    logging.info(json_string)
                    event_data_batch.add(EventData(json_string))
                    # logging.info(json_string)
                producer.send_batch(event_data_batch)
                logging.info("OUTSIDE LOOP!!!")
                print(event_data_batch)
                
        except Exception as e:
            logging.info("RAISING EXCEPTION")
            logging.info(str(e))
            raise Exception(str(e))
    else:
        logging.info("*****************NO DATA TO SEND TO THE EVENTHUB********************************")
        

def get_alarms_config(cnxn, siteId):
    sql = f"""select SITE_ID, CURRENT_LATEST_DATETIME,EventHub_ConnStr FROM DATA_ALARMS_CONFIG where SITE_ID={siteId}"""
    temp_df = pd.read_sql(sql,cnxn)
    return temp_df

def update_latest_dateTime(cursor,cnxn, dateTime, siteId):
    sql = f"""UPDATE DATA_ALARMS_CONFIG SET CURRENT_LATEST_DATETIME='{dateTime}' where SITE_ID={siteId}"""
    # print('update script: '+sql)
    cursor.execute(sql)
    cnxn.commit()
    

def dataAlarm_to_sqlServer(df,cnxn,cursor):

    if not df.empty:
        logging.info("############################################################################################################")
        logging.info("INCOMING DF")
        logging.info(df)
        # df = df[['DataAlarmActionGUID','DataAlarm_ID','State_ID','AST_ID','Current_Value','Reading_Time','action_ID']]
        # df['Reading_Time'] = pd.to_datetime(df.Reading_Time)
        # df['Reading_Time'] = df['Reading_Time'].dt.strftime('%Y%m%d %H:%M:%S')
        df.dropna(subset = ["Reading_Time"], inplace=True)

        df = df[(df['action_ID'] != 3) | (df['IsActive'] != 1) ]
        df["AST_ID"].fillna("Null", inplace = True)
        df["Current_Value"].fillna("Null", inplace = True)
        # cursor = cnxn.cursor()
        # creating column list for insertion
        cols = "`,`".join([str(i) for i in df.columns.tolist()])
        # Insert DataFrame recrds one by one.
        df.sort_values(by='Reading_Time', inplace=True)
        for index, row in df.iterrows():
            logging.info("************************SQL ROWS************************************")
            logging.info(row)
        logging.info("************************SQL ROWS ENDS************************************")
        try:
            # Insert Dataframe into SQL Server:
            for index, row in df.iterrows():
                sql = f"INSERT INTO DATA_ALARM_ACTION (DataAlarmActionGUID,DataAlarm_ID,State_ID,AST_ID,Current_Value,Reading_Time,AS_Id, isActive) values ('{row.DataAlarmActionGUID}',{row.DataAlarm_ID},{row.State_ID}, {row.AST_ID},{row.Current_Value},CAST(N'{row.Reading_Time}' AS DateTime),2, {row.IsActive})"
                # logging.info(sql)
                cursor.execute(sql)
            # logging.info(sql)
            cnxn.commit()
            logging.info("Data ingested into SQL")
            #df = df[0:0]
        except:
            raise Exception("Loading into SQL Failed.")
        # the connection is not autocommitted by default, so we must commit to save our changes
    else:
        logging.info("*****************NO DATA TO INGEST INTO SQL********************")

def get_raw_alarms(cnxn, site_id):
    sql = f"""select dc.AST_ID,ds.State_Title,ds.State_ID,d.DataAlarm_ID,dc.Value,rt.R_Mapped_Name,dc.isAlarmOn,dc.AS_Id, dc.Alarm_Processed from DATA_ALARM_STATES_CONFIG dc 
            inner join DATA_ALARM d 
            on dc.DataAlarm_ID=d.DataAlarm_ID
            inner join DATA_ALARM_STATES ds
            on dc.State_ID=ds.State_ID
            inner join Real_Raw_Points rt
            on d.Real_Tag_Id=rt.Real_Tag_Id
            where rt.Site_Id_FK={site_id} and isAlarmOn=1 and ds.State_ID in (1,2,4,5,11,12)"""

    temp_df = pd.read_sql(sql,cnxn)
    return temp_df

def get_calc_alarms(cnxn, site_id):
    sql = f"""select dc.AST_ID,ds.State_Title,ds.State_ID,d.DataAlarm_ID,dc.Value,ct.C_Tag_Name,dc.IsAlarmOn,dc.AS_Id, dc.Alarm_Processed from DATA_ALARM_STATES_CONFIG dc 
                inner join DATA_ALARM d 
                on dc.DataAlarm_ID=d.DataAlarm_ID
                inner join DATA_ALARM_STATES ds
                on dc.State_ID=ds.State_ID
                inner join Calculated_Tags ct
                on d.C_Tag_Id=ct.C_Tag_Id
                where ct.Site_Id_FK={site_id} and isAlarmOn=1 and ds.State_ID in (1,2,4,5,11,12)"""

    temp_df = pd.read_sql(sql,cnxn)
    return temp_df

def get_raw_status_alarms(cnxn, site_id):
    sql = f"""select d.DataAlarm_ID,opctp.SCT_Title as State_Title,opctp.SCT_Id as State_ID,rt.R_Mapped_Name,d.IsDataAlarmOn from OPC_QualityCodetTypes_DATA_ALARM_M2M opcm2m
            inner join DATA_ALARM d
            on d.DataAlarm_ID=opcm2m.DataAlarm_ID
            inner join OPC_QualityCodetTypes opctp
            on opcm2m.SCT_Id=opctp.SCT_Id
            inner join Real_Raw_Points rt
            on d.Real_Tag_Id=rt.Real_Tag_Id
            where rt.Site_Id_FK={site_id} and IsDataAlarmOn=1 """

    temp_df = pd.read_sql(sql,cnxn)
    return temp_df
    
def get_calc_status_alarms(cnxn, site_id):
    sql = f"""select opctp.SCT_Title as State_Title,opctp.SCT_Id as State_ID,d.DataAlarm_ID,ct.C_Tag_Name,d.isDataAlarmOn from OPC_QualityCodetTypes_DATA_ALARM_M2M opcm2m
            inner join DATA_ALARM d
            on d.DataAlarm_ID=opcm2m.DataAlarm_ID
            inner join OPC_QualityCodetTypes opctp
            on opcm2m.SCT_Id=opctp.SCT_Id
            inner join Calculated_Tags ct
            on d.C_Tag_Id=ct.C_Tag_Id
            where ct.Site_Id_FK={site_id} and isDataAlarmOn=1  """

    temp_df = pd.read_sql(sql,cnxn)
    return temp_df

def raw_interpolation_query(raw_list):
    makeSeries_query = "| make-series "
    mvExpand_query = "| mv-expand TimeStamp, "
    extend_query = "| extend TimeStamp=todatetime(TimeStamp), "
    project_query = "| project TimeStamp,"

    for x in raw_list:
        makeSeries_query += str(x) + '=avg(todouble(' + str(x) + ')), '
        makeSeries_query += 'S_' + str(x) + '=any(column_ifexists(' + '"unpack_' + str(x) + '",0)), ' 
        mvExpand_query += str(x) + '=series_fill_linear(' + str(x) + '), '  #'R' + str(x) + ', '
        mvExpand_query += 'S_' + str(x) + '=series_fill_linear(' + 'S_' + str(x) + '), '
        extend_query += str(x) + '=toreal(' + str(x) + '), '
        extend_query += 'S_' + str(x) + '=toreal(' + 'S_' + str(x) + '), '
        project_query += str(x) + ','

    makeSeries_query = makeSeries_query[:-2]
    makeSeries_query += ' on TimeStamp step 1s'

    extend_query = extend_query[:-2]

    mvExpand_query = mvExpand_query[:-2]

    project_query = project_query[:-1]
    
    return makeSeries_query+'\n'+mvExpand_query+'\n'+extend_query

def calc_interpolation_query(tags_list):
    project_query   =   "| project TimeStamp,"      #unpack_Calc_Tag1_Code
    
    for x in tags_list:
        project_query += str(x)  + ','
        project_query += "S_" + str(x) + """=column_ifexists("unpack_""" + str(x) + """_Code",double(NaN))""" + ',' 

    project_query = project_query[:-1]
    
    return project_query

def log_entry(cursor,cnxn,TS,site_id,Type,Status,Exec_ID, Stage="", Error=""):
    if Error != "":
        Error = eval(Error)
        Error = Error[0]['error']['@message'].replace("'", "")

    sql_query = """
    INSERT INTO Automation_Logs (TimeStamp, Site_Id, Type_of_execution, Status, Stage, Error, Execution_ID)
    VALUES ('"""+str(TS)+"""','"""+str(site_id)+"""','"""+Type+"""','"""+Status+"""','"""+Stage+"""','"""+str(Error)+"""','"""+Exec_ID+"""')
    """
    cursor.execute(sql_query)
    cnxn.commit()

def set_alarm_dict(alarm_config_list):
    for i in range(0,len(alarm_config_list)):
        if(alarm_config_list[i][5]=="High High"):
            currentTag = alarm_config_list[i][3]
            thresholdVal = alarm_config_list[i][4]
            
            dict_hh[currentTag] = thresholdVal   
        elif(alarm_config_list[i][5]=="Low Low"):            
            currentTag = alarm_config_list[i][3]
            thresholdVal = alarm_config_list[i][4]
            
            dict_ll[currentTag] = thresholdVal
                         
def kusto_execute(db,query,kusto_client,return_df=False):
    response = kusto_client.execute(db, query)
    if return_df == True:
        return dataframe_from_result_table(response.primary_results[0])

def is_calc_updated(site_name, kusto_client,alarms_columns):
    get_schema_query = "Calc_"+site_name+"\n| getschema\n| project ColumnName"
    df = kusto_execute(site_name, get_schema_query,kusto_client, return_df=True)
    # TODO: fix calc updated tags 
    #Alter query for new tags
    alter_tags = []
    for x in alarms_columns:
        if x not in list(df['ColumnName']):
            alter_tags.append(x)

    if(len(alter_tags)>0):
        return False
    else:
        logging.info("###################IS CALC UPDATED FUNCTION RETURNS TRUE###############")
        return True


def update_alarmProcess(cursor, cnxn,AST_ID):
    sql = f"""UPDATE DATA_ALARM_STATES_CONFIG SET Alarm_Processed=1 where AST_ID={AST_ID}"""
    cursor.execute(sql)
    cnxn.commit()


def populate_alarms(df,tagAST_ID,tagDataAlarmID,stateId,alarmState,action,currentTag):
    df.loc[(df['changeDetected'] == True), 'DataAlarm_ID']              = tagDataAlarmID
    df.loc[(df['changeDetected'] == True), 'AST_ID']                    = tagAST_ID
    df.loc[(df['changeDetected'] == True), 'Current_Value']             = df[currentTag]
    df.loc[(df['changeDetected'] == True), 'Reading_Time']              = df['TimeStamp']
    df.loc[(df['changeDetected'] == True), 'AlarmType']                 = alarmState
    df.loc[(df['changeDetected'] == True), 'TAGNAME']                   = currentTag
    df.loc[(df['changeDetected'] == True), 'State_ID']                  = stateId
    df.loc[(df['changeDetected'] == True), 'action_ID']                 = action
    logging.info("############################################################################################################")
    logging.info("Populate alarms values")
    #print(df.head(100).) 
    logging.info("PRINTING CHANGE DETECTED DF")
    logging.info(df.loc[df['changeDetected'] == True].head(10))

def populate_inactive_alarms(df,tagAST_ID,tagDataAlarmID,stateId, alarmState,currentTag):
    logging.info("********Alarmdisbaled********")
    df.loc[(df['alarmDisabled'] == True), 'alarmDisabled_State']  = alarmState
    
    df.loc[(df['alarmDisabled'] == True), 'tmpAST_ID']            = tagAST_ID
    df.loc[(df['alarmDisabled'] == True), 'tmpCurrent_Value']     = df[currentTag]
    df.loc[(df['alarmDisabled'] == True), 'tmpReading_Time']      = df['TimeStamp']
    df.loc[(df['alarmDisabled'] == True), 'tmpDataAlarm_ID']      = tagDataAlarmID
    df.loc[(df['alarmDisabled'] == True), 'tmpState_ID']          = stateId
    logging.info("############################################################################################################")
    logging.info("PRINTING ALARM DISABLED DF")
    logging.info(df.loc[df['alarmDisabled'] == True].info())
    logging.info("********Alarmdisbaled PART TWO********")

def process_first_timers(df,currentTag,inf):
    if not (pd.isnull(df.loc[0, currentTag])):  # if first row is not null then add a dummy row
        row_1=df.head(1)
        row_1[currentTag] = None
        df = pd.concat([row_1, df], ignore_index=True)
    df[currentTag] = df[currentTag].where(df[currentTag].ffill().notna(), float(inf))
    return df

def get_latest_alarms(cnxn):
    sql = f"""SELECT distinct t.Reading_Time,t.DataAlarm_ID,t.State_ID FROM DATA_ALARM_ACTION t INNER JOIN      
    (SELECT MAX(Reading_Time) as Reading_Time,DataAlarm_ID
    FROM DATA_ALARM_ACTION
    GROUP BY DataAlarm_ID 
    ) t2
    on t.Reading_Time = t2.Reading_Time and t.DataAlarm_ID = t2.DataAlarm_ID
    where isActive=1"""

    temp_df = pd.read_sql(sql,cnxn)
    return temp_df

def get_latest_alarms_blob(file_name):
    logging.info(file_name)
    BLOBNAME= file_name
    CONTAINERNAME= "sql-configs"
    # actual connection string being used for pocadx2
    # connection_string = "BlobEndpoint=https://alarmsengine.blob.core.windows.net/;QueueEndpoint=https://alarmsengine.queue.core.windows.net/;FileEndpoint=https://alarmsengine.file.core.windows.net/;TableEndpoint=https://alarmsengine.table.core.windows.net/;SharedAccessSignature=sv=2020-08-04&ss=bfqt&srt=sco&sp=rwdlacupitfx&se=2022-12-31T14:22:09Z&st=2022-05-24T06:22:09Z&spr=https&sig=qw1Wt1bqn75LWpgwp6yA2MCfXHJCfv0%2F8a0a4LEylts%3D"
    connection_string =   "BlobEndpoint=https://sandboxdataalarm.blob.core.windows.net/;QueueEndpoint=https://sandboxdataalarm.queue.core.windows.net/;FileEndpoint=https://sandboxdataalarm.file.core.windows.net/;TableEndpoint=https://sandboxdataalarm.table.core.windows.net/;SharedAccessSignature=sv=2022-11-02&ss=bfqt&srt=s&sp=rwdlacupiytfx&se=2023-12-31T15:27:54Z&st=2023-05-25T07:27:54Z&spr=https&sig=Pog0xvkhPtJSE2gABlj19t8VGyhrq8wDHtdCbqF8nUs%3D"
    
    blob = BlobClient.from_connection_string(conn_str=connection_string, container_name=CONTAINERNAME, blob_name=BLOBNAME)

    blob_data = blob.download_blob()

    blob_string = blob_data.readall().decode("utf-8") 

    df = pd.read_csv(StringIO(blob_string))
    logging.info("*************************************GET LATEST ALRMS BLOB *******************")
    logging.info(df)

    return df

def detectChange(cursor, cnxn,df,tagAstID,tagDataAlarmID,stateId,tagName,tagValue, alarmState,alarmAction, alarmProcessed,df_latest_triggered_alarms):
    
    global dict_hh,dict_ll
    populate_db = False
    df_latest_triggered_alarms = df_latest_triggered_alarms.copy()

    tagAST_ID               =   tagAstID
    tagDataAlarmID          =   tagDataAlarmID
    currentTag              =   tagName
    thresholdVal            =   tagValue
    stateId                 =   stateId
    action                  = alarmAction

    df_latest_alarms = df_latest_triggered_alarms.loc[df_latest_triggered_alarms['DataAlarm_ID'] == tagDataAlarmID]
    df_latest_alarms = df_latest_alarms.sort_values(by=['Reading_Time'])
    
    if not df_latest_alarms.empty:
        latest_state_id = df_latest_alarms.iloc[0]['State_ID']
    else:
        latest_state_id = None

    df= df.copy()
    if(df.empty):
        return None

    df = df.sort_values(by=['TimeStamp'])

    df[currentTag] = df[currentTag].fillna(method="ffill")
    df["S_" + currentTag] = df["S_" + currentTag].fillna(method="ffill")

    if "High" in alarmState:
        if (alarmState == 'High High'):
            if ((alarmProcessed   ==  0) | ((stateId!=latest_state_id) and stateId!=None)):
                df = process_first_timers(df,currentTag,'-inf')

            df['changeDetected']    = ((df[currentTag]<thresholdVal) & (df[currentTag].shift(periods=-1) >=thresholdVal)).shift(periods=1)
            if ((alarmProcessed== 0) & (True in df['changeDetected'].unique())):
                update_alarmProcess(cursor, cnxn, tagAST_ID)
                populate_db = True

            populate_alarms(df,tagAST_ID,tagDataAlarmID,stateId,alarmState,action,currentTag)
            
            df['alarmDisabled']     = ((df[currentTag] >= thresholdVal) & (df[currentTag].shift(periods=-1) < thresholdVal)).shift(periods=1)
            
            populate_inactive_alarms(df,tagAST_ID,tagDataAlarmID,stateId, alarmState,currentTag)

        elif (alarmState == 'High'):
            positive_infinity = float('inf')

            if currentTag in dict_hh.keys():
                upper_bound = dict_hh[currentTag]
            else:
                upper_bound = positive_infinity

            if ((alarmProcessed   ==  0) | ((stateId!=latest_state_id) and stateId!=None)):
                df = process_first_timers(df,currentTag,'-inf')
                    
            df['changeDetected'] = (((df[currentTag]<thresholdVal) | (df[currentTag]>=upper_bound)) & ((df[currentTag].shift(periods=-1) >=thresholdVal) & (df[currentTag].shift(periods=-1) <upper_bound))).shift(periods=1)
            if ((alarmProcessed== 0) & (True in df['changeDetected'].unique())):
                update_alarmProcess(cursor, cnxn, tagAST_ID)
                populate_db = True

            populate_alarms(df,tagAST_ID,tagDataAlarmID,stateId,alarmState,action,currentTag)

            df['alarmDisabled'] =   (((df[currentTag]>=thresholdVal) & (df[currentTag]< upper_bound)) & ((df[currentTag].shift(periods=-1) <thresholdVal) | (df[currentTag].shift(periods=-1) >= upper_bound))).shift(periods=1)
            
            populate_inactive_alarms(df,tagAST_ID,tagDataAlarmID,stateId, alarmState,currentTag)


    elif "Low" in alarmState:
        if (alarmState == 'Low Low'):
            if ((alarmProcessed   ==  0) | ((stateId!=latest_state_id) and stateId!=None)):
                df = process_first_timers(df,currentTag,'inf')
                
            df['changeDetected']    = ((df[currentTag]> thresholdVal) & ((df[currentTag].shift(periods=-1) <=thresholdVal) )).shift(periods=1)
            if ((alarmProcessed== 0) & (True in df['changeDetected'].unique())):
                update_alarmProcess(cursor, cnxn, tagAST_ID)
                populate_db = True

            populate_alarms(df,tagAST_ID,tagDataAlarmID,stateId,alarmState,action,currentTag)

            df['alarmDisabled']     = ((df[currentTag] <= thresholdVal) & (df[currentTag].shift(periods=-1) > thresholdVal)).shift(periods=1)
            
            populate_inactive_alarms(df,tagAST_ID,tagDataAlarmID,stateId, alarmState,currentTag)


        elif (alarmState == 'Low'):
            negative_infinity = float('-inf')
            if currentTag in dict_ll.keys():
                lower_bound = dict_ll[currentTag]
            else:
                lower_bound = negative_infinity

            if ((alarmProcessed   ==  0) | ((stateId!=latest_state_id) and stateId!=None)):
                df = process_first_timers(df,currentTag,'inf')

            df['changeDetected'] = (((df[currentTag] > thresholdVal) | (df[currentTag] <=lower_bound)) & ((df[currentTag].shift(periods=-1) <=thresholdVal) & ((df[currentTag].shift(periods=-1) >lower_bound)))).shift(periods=1)
            if ((alarmProcessed== 0) & (True in df['changeDetected'].unique())):
                update_alarmProcess(cursor, cnxn, tagAST_ID)
                populate_db = True

            populate_alarms(df,tagAST_ID,tagDataAlarmID,stateId,alarmState,action,currentTag)

            df['alarmDisabled'] = (((df[currentTag] <= thresholdVal) & (df[currentTag] > lower_bound)) & ((df[currentTag].shift(periods=-1) > thresholdVal) | (df[currentTag].shift(periods=-1) <= lower_bound))).shift(periods=1)
            
            populate_inactive_alarms(df,tagAST_ID,tagDataAlarmID,stateId, alarmState,currentTag)


    elif "Bad Values" in alarmState:
        ScurrentTag = "S_" + currentTag
        
        if ((alarmProcessed   ==  0) | ((stateId!=latest_state_id) and stateId!=None)):
            if not (pd.isnull(df.loc[0, ScurrentTag])):  # if first row is not null then add a dummy row
                row_1=df.head(1)
                row_1[ScurrentTag] = None
                df = pd.concat([row_1, df], ignore_index=True)
            df[ScurrentTag] = df[ScurrentTag].where(df[ScurrentTag].ffill().notna(), 1)
        
        df['changeDetected'] = ((df[ScurrentTag]!=0) & (df[ScurrentTag].shift(periods=-1) ==0)).shift(periods=1)

        if ((alarmProcessed== 0) & (True in df['changeDetected'].unique())):
            update_alarmProcess(cursor, cnxn, tagAST_ID)
            populate_db = True

        populate_alarms(df,tagAST_ID,tagDataAlarmID,stateId,alarmState,action,currentTag)

        df['alarmDisabled']                     = ((df[ScurrentTag] == 0) & (df[ScurrentTag].shift(periods=-1) != 0)).shift(periods=1)
        
        populate_inactive_alarms(df,tagAST_ID,tagDataAlarmID,stateId, alarmState,currentTag)

    elif "Uncertain" in alarmState:
        ScurrentTag = "S_" + currentTag
        
        if ((alarmProcessed   ==  0) | ((stateId!=latest_state_id) and stateId!=None)):
            if not (pd.isnull(df.loc[0, ScurrentTag])):  # if first row is not null then add a dummy row
                row_1=df.head(1)
                row_1[ScurrentTag] = None
                df = pd.concat([row_1, df], ignore_index=True)
            df[ScurrentTag] = df[ScurrentTag].where(df[ScurrentTag].ffill().notna(), 1)
        
        df['changeDetected']                    = ((df[ScurrentTag]!=2) & (df[ScurrentTag].shift(periods=-1) ==2)).shift(periods=1)

        if ((alarmProcessed== 0) & (True in df['changeDetected'].unique())):
            update_alarmProcess(cursor, cnxn, tagAST_ID)
            populate_db = True
        
        populate_alarms(df,tagAST_ID,tagDataAlarmID,stateId,alarmState,action,currentTag)

        df['alarmDisabled']                     = ((df[ScurrentTag] == 2) & (df[ScurrentTag].shift(periods=-1) != 2)).shift(periods=1)
        
        populate_inactive_alarms(df,tagAST_ID,tagDataAlarmID,stateId, alarmState,currentTag)

    df2 = df[["tmpDataAlarm_ID", "tmpAST_ID","tmpReading_Time","tmpState_ID"]].copy()
    df2=df2.rename(columns={'tmpAST_ID': 'AST_ID', 'tmpReading_Time': 'Reading_Time','tmpDataAlarm_ID': 'DataAlarm_ID','tmpState_ID':'State_ID'})
    df2 = df2.dropna()
    df['IsActive']    =   1
    df2['IsActive']   =   0

    final_df = pd.concat([df,df2], ignore_index=True)
    final_df['DataAlarmActionGUID']   = [str(uuid.uuid4()) for x in range(len(final_df))]
    final_df['AlarmType']             = 'Data_Alarms'
    logging.info("***********************FINAL DF OUTSIDE ALL 4 STATES!!**********************************")
    logging.info(final_df)
    return final_df, populate_db



def get_project_query(site_name,temp_df, _whereStr):
    list_of_devices = list(temp_df['Site_Specific_Device_Id'].unique())
 
    ingestion_table = "Raw_"+site_name


    raw_tags_dict = {}
    for x in list_of_devices:
        temp_df2 = temp_df.loc[temp_df['Site_Specific_Device_Id'] == x]
        raw_tags_dict[x] = dict(zip(list(temp_df2['R_Mapped_Name']),['R' + element for element in map(str,list(temp_df2['R_Mapped_By_Device']))]))


    # list_of_devices = list(temp_df['Site_Specific_Device_Id'].unique())
#     list_of_devices = list(raw_tags_dict.keys())
    num_of_devices = len(list_of_devices)
    if len(list_of_devices) > 1:
        join_check = True
    else:
        join_check = False
    close_join = False

    self_join_query = ""
    for x in list_of_devices:
        self_join_query += ingestion_table + _whereStr +"\n|  where ID == "+str(x)+"\n| evaluate bag_unpack(StatusCode,'unpack_')\n"
        project = "| project TimeStamp = todatetime(format_datetime(TimeStamp,'yyyy-MM-dd HH:mm:ss')) , "
        for y in raw_tags_dict[x]:
            project +=  y +"=round("+raw_tags_dict[x][y] + ",0),"
            project += 'S_' + y + '=round((column_ifexists("unpack_' + raw_tags_dict[x][y] + '",double(NaN))),0),'


        project = project[:-1]
        self_join_query += project + "\n" 

        if close_join == True:
            self_join_query += ") on $left.TimeStamp == $right.TimeStamp\n| extend TimeStamp = iif(isnull(TimeStamp),TimeStamp1,TimeStamp)\n| project-away TimeStamp1\n"
            if num_of_devices <= 1:
                join_check = False
        if join_check == True:
            self_join_query += "| join kind=fullouter (" + "\n"
            close_join = True

        num_of_devices -= 1

    return self_join_query



def get_rawdf(tags_list,site_id,cnxn):
    raw_list_string = "("
    for x in tags_list:
        raw_list_string += "'" + x + "',"
    raw_list_string = raw_list_string[:-1]
    raw_list_string += ")"

    #Get Dataframe
    sql = """SELECT * FROM Real_Raw_Points WHERE Site_Id_FK = """+str(site_id)+""" AND R_Mapped_Name in """ + raw_list_string
    temp_df = pd.read_sql(sql,cnxn)

    return temp_df

def data_lag(db,kusto_client,current_latest_date):
    query       =   'Raw_'+db+ '| where TimeStamp> datetime('+str(current_latest_date)+ ')| summarize  Min_Time=max(TimeStamp)'
    print(query)
    response    =   kusto_client.execute(db, query)
    df          =   dataframe_from_result_table(response.primary_results[0])
    print(df)
    try:
        df          =   dt.strptime(str(df['Min_Time'][0]), '%Y-%m-%d %H:%M:%S.%f+00:00')
    except:
        return {
                "min_dateTime_new"   : None,
                "delta_time"         : 0
        }
    dateformat              =   '%Y-%m-%d %H:%M:%S'
    min_date_new_interval   =   dt.strptime(str(df)[:-7], dateformat)
    max_date_last_interval  =   dt.strptime(current_latest_date, dateformat)
    
    delta_time              =   min_date_new_interval -   max_date_last_interval
    time_dict   =   {
                "min_dateTime_new"   : min_date_new_interval,
                "delta_time"         : (delta_time.total_seconds())/3600
        }

    return time_dict
    
# def create_session():
#     spk = SparkSession.builder \
#         .master("local") \
#         .appName("Product_mart.com") \
#         .getOrCreate()
#     return spk

# def create_df(spark, data, schema):
#     df1 = spark.createDataFrame(data, schema)
#     return df1

def main(mytimer: func.TimerRequest) -> None:
    logging.info('Python HTTP trigger function processed a request.')
    
    # site_id = int(req.params.get('site_id'))
    # database_name = req.params.get('database_name')
    site_id         = os.environ["site_id"]
    database_name   = os.environ["database_name"]
    #Connect to SQL
    server = 'tcp:octopusdigitalsql.database.windows.net'
    database = database_name #'OMNIConnect_Staging' #'DemoOmniconnect'
    username = 'octopusdigital' 
    password = os.environ["Database_Key"]
    cnxn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)
    cursor = cnxn.cursor()

    #Connect to Kusto Client
    # logging.info(cursor)
    cluster = "https://sandboxadx.southeastasia.kusto.windows.net/"
    kcsb = KustoConnectionStringBuilder.with_aad_application_key_authentication(cluster, client_id, client_secret, AAD_TENANT_ID)
    kusto_client = KustoClient(kcsb)

    alarms_configuration_sql= get_alarms_config(cnxn, site_id)
    current_latest_date= alarms_configuration_sql['CURRENT_LATEST_DATETIME'][0]
    
    # current_latest_date =   '2022-02-21 10:30:11'
    
    logging.info("Current Latest Date: "+current_latest_date)
    catchup_interval = "10m"

    if(current_latest_date == ""):
        catchup_interval = None
    
    site_name=get_site_name(cnxn,site_id)

    if(database_name=="OMNIConnect_Staging"):
        blob_name = "latest_alarms_staging.csv"
    elif(database_name=="OMNIConnect_Production"):
        blob_name = "latest_alarms_replica.csv"
    else:
        blob_name = "latest_alarms_prod.csv"

    df_latest_triggered_alarms = get_latest_alarms_blob(blob_name)
    # cldt               = '2022-02-06 16:53:33'

    i=9
    while True:
        if site_id and database_name:
            try:
                if (current_latest_date != ""):
                    delta_time         = data_lag(site_name, kusto_client, current_latest_date) #Lag between last and current run
                    ingestion_lag      = str(delta_time['delta_time'])
                    logging.info('Ingestion Lag duration (hours): '+ ingestion_lag)
                    
                    if (float(ingestion_lag)> float(12)):
                        catchup_interval        =   dt.strptime(str(current_latest_date), '%Y-%m-%d %H:%M:%S')   
                        catchup_interval       +=   timedelta(hours=6)
                
                # # ----------------------- Detect Changes for Calc ---------------------------------
                calc_alarms_configuration_DF        =   get_calc_alarms(cnxn,site_id)
                calc_alarms_configuration_DF        =   calc_alarms_configuration_DF[['AST_ID','DataAlarm_ID','State_ID','C_Tag_Name', 'Value','State_Title','AS_Id', 'Alarm_Processed']]
                calc_tags_list                      =   list(set(calc_alarms_configuration_DF['C_Tag_Name'].tolist()))
                calc_tags_list.sort()

                calc_alarms_configuration_DF_list= calc_alarms_configuration_DF[['AST_ID','DataAlarm_ID','State_ID','C_Tag_Name', 'Value','State_Title', 'AS_Id','Alarm_Processed']].values.tolist()
                logging.info("calc_alarms_configuration_DF_list")
                logging.info(calc_alarms_configuration_DF_list)
                final_change_detected_calc_df = pd.DataFrame()

                if ((len(calc_alarms_configuration_DF_list)>0) & is_calc_updated(site_name,kusto_client,calc_tags_list) ):
                    # logging.info("Calculated alarms are not empty")
                    calc_function_query             =   "Calc_"+get_site_name(cnxn,site_id)+"\n| evaluate bag_unpack(Calc_Status_Code,'unpack_')\n"
                    
                    # calc_tags_list = list(set(calc_tags_list + status_tags_list))
                    calc_tag_query                  =   calc_function_query+calc_interpolation_query(calc_tags_list) 
                    
                    if(catchup_interval is None): 
                        query   =   calc_tag_query
                    else:
                        if (float(ingestion_lag)<= float(12)):
                            index   =   calc_tag_query.find(')')
                            query   =   calc_tag_query[:index+1] + '| where TimeStamp>= datetime('+str(current_latest_date) +calc_tag_query[index:]
                        elif (float(ingestion_lag)> float(12)):
                            index   =   calc_tag_query.find(')')
                            query   =   calc_tag_query[:index+1] + '| where TimeStamp>= datetime('+str(current_latest_date)+ ') and TimeStamp<= datetime('+str(catchup_interval) +calc_tag_query[index:]
                    
                    logging.info(query)
                    logging.info("query")

                    
                    response = kusto_client.execute(site_name,query)

                    df_calc_tags = []
                    df_calc_tags = dataframe_from_result_table(response.primary_results[0])
                    logging.info("************DF CALC TAGS!!***************")
                    logging.info(df_calc_tags)

                    final_change_detected_calc_df = pd.DataFrame()
                    
                    # logging.info(alarms_configuration)
                    set_alarm_dict(alarm_config_list=calc_alarms_configuration_DF_list)
                    
                    # print('Calculated alarms config list: ',calc_alarms_configuration_DF_list)
                    df_with_calc_alarams= pd.DataFrame()
                    try:
                        for tagName in range(0,len(calc_alarms_configuration_DF_list)):
                            temp_df,populate_db = detectChange(cursor, cnxn,df_calc_tags,calc_alarms_configuration_DF_list[tagName][0]
                            ,calc_alarms_configuration_DF_list[tagName][1],calc_alarms_configuration_DF_list[tagName][2]
                            ,calc_alarms_configuration_DF_list[tagName][3],calc_alarms_configuration_DF_list[tagName][4]
                            ,calc_alarms_configuration_DF_list[tagName][5],calc_alarms_configuration_DF_list[tagName][6]
                            ,calc_alarms_configuration_DF_list[tagName][7],df_latest_triggered_alarms)

                            if populate_db == True:
                                df_with_calc_alarams=pd.concat([df_with_calc_alarams,temp_df])
                                logging.info("**************df_with_calc_alarms if conditon***************")
                                logging.info(df_with_calc_alarams)
                                
                                final_change_detected_calc_df= df_with_calc_alarams[['DataAlarmActionGUID','DataAlarm_ID','AST_ID','State_ID','Current_Value','Reading_Time','AlarmType','action_ID','IsActive']]
                                final_change_detected_calc_df.dropna(subset = ["DataAlarmActionGUID","Reading_Time"], inplace=True)
                                logging.info("*************FINAL CHANGE DETECTED DF CALCULATED if condition*************")
                                logging.info(final_change_detected_calc_df.head())

                            else:
                                logging.info("**************************INSIDE ELSE PASS for CALC**********************************")
                                pass
                                # df_with_alarams=df_latest_triggered_alarms
                                # logging.info("************df_with_alarams else condition******************")
                                # logging.info(df_with_alarams.columns)
                                # logging.info("***************************************************************")

                                # list_of_columns = ['DataAlarmActionGUID','DataAlarm_ID','AST_ID','State_ID','Current_Value','Reading_Time','AlarmType','action_ID','IsActive']
                                # for df_col in list_of_columns:
                                #     if df_col not in df_with_alarams.columns:      
                                #         df_with_alarams[df_col] = ""
                                # final_change_detected_calc_df= df_with_alarams[list_of_columns]

                                # #for ind in df_with_alarams.index:
                                # logging.info("@@@@@@@@@@@@@@@@ INSIDE QUERY LOOP @@@@@@@@@@@@@@@@@@@@@@@")
                                # col_names = ','.join(str(v) for v in df_latest_triggered_alarms['DataAlarm_ID'].tolist())
                                # query_other_columns = 'select DataAlarmActionGUID,AST_ID,Current_Value,IsActive from DATA_ALARM_ACTION where dataalarm_id IN ({col_names})'.format(col_names=col_names)
                                # logging.info("*******************EACH COLUMN VALUE******************")
                                # logging.info(query_other_columns)
                                # df_with_alarams.append(pd.read_sql(query_other_columns,cnxn))

                                
                                # logging.info("@@@@@@@@@@@@@@@@@@@@@@@2df_with_alarams@@@@@@@@@@@@@@@@@@@@@")
                                # logging.info(df_with_alarams)

                                # #Index(['Unnamed: 0', 'Reading_Time', 'DataAlarm_ID', 'State_ID'], dtype='object')
                                # final_change_detected_calc_df= df_with_alarams[['DataAlarmActionGUID','DataAlarm_ID','AST_ID','State_ID','Current_Value','Reading_Time','AlarmType','action_ID','IsActive']]
                                # final_change_detected_calc_df.dropna(subset = ["DataAlarmActionGUID","Reading_Time"], inplace=True)
                                # logging.info("*************FINAL CHANGE DETECTED DF CALCULATED else condition*************")
                                # logging.info(final_change_detected_calc_df.head())

                        # if not df_with_calc_alarams.empty:
                            
                        #     final_change_detected_calc_df= df_with_calc_alarams[['DataAlarmActionGUID','DataAlarm_ID','AST_ID','State_ID','Current_Value','Reading_Time','AlarmType','action_ID','IsActive']]
                        #     final_change_detected_calc_df.dropna(subset = ["DataAlarmActionGUID","Reading_Time"], inplace=True)
                        #     # final_change_detected_calc_df = final_change_detected_calc_df.reindex(columns=['DataAlarmActionGUID','Current_Value','action_ID','IsActive','AlarmType','AST_ID'])

                        #     logging.info("*************FINAL CHANGE DETECTED DF CALCULATED*************")
                        #     logging.info(final_change_detected_calc_df)
                        
                    except:
                        pass
                    # logging.info(final_change_detected_calc_df)
                    # final_change_detected_calc_df.to_csv("testing.csv")

                # # ----------------------- Detect Changes for Raw ---------------------------------
                alarms_configuration_DF         =   get_raw_alarms(cnxn,site_id)
                alarms_configuration_DF         =   alarms_configuration_DF[['AST_ID','DataAlarm_ID','State_ID','R_Mapped_Name', 'Value','State_Title','AS_Id','Alarm_Processed']] 
                # print('Raw alarms config df: \n',alarms_configuration_DF)
                tags_list                       =   list(set(alarms_configuration_DF['R_Mapped_Name'].tolist()))
                print("tag")
                print(tags_list)
                tags_list.sort()

                alarms_configuration= alarms_configuration_DF[['AST_ID','DataAlarm_ID','State_ID','R_Mapped_Name', 'Value','State_Title','AS_Id','Alarm_Processed']].values.tolist()
                print("***************************      HERE *************************************")
                if(len(tags_list)==0):
                    latest_current_time = dt.now().strftime("%Y-%m-%d %H:%M:%S")
                else:
                    raw_df      = get_rawdf(tags_list,site_id,cnxn)
                    #quering the data from Raw table
                    if(catchup_interval is None): #if Raw table is empty then copy all data in main
                        query = get_project_query(site_name,raw_df,'')
                    else:
                        if (float(ingestion_lag)<= float(12)):
                            whereStr    =   '| where TimeStamp>= datetime('+str(current_latest_date)+')'
                            query   =   get_project_query(site_name,raw_df,whereStr)
                        elif (float(ingestion_lag)> float(12)):
                            whereStr    =    '| where TimeStamp>= datetime('+str(current_latest_date)+ ') and TimeStamp<= datetime('+str(catchup_interval)+')'
                            query   =   get_project_query(site_name,raw_df,whereStr)
                    logging.info("***********************RAW QUERY *******************************")
                    logging.info(query)
                    response = kusto_client.execute(site_name,query)
                    logging.info("*****************RESPONSE*************************")
                    logging.info(response)
                    # for row in response.primary_results[0]:
                    #      logging.info("value at 0 {}".format(row[0]))
                    #      print("\n")
                    #      print("EventType:{}".format(row["EventType"]))

                    df_k = dataframe_from_result_table(response.primary_results[0])
                    logging.info("################## FRAME  INFO ###################")
                    logging.info(df_k.info)
                    logging.info("################## FRAME  INFO ENDS ###################")
                    logging.info("*********************DF_K ************************")
                    logging.info(df_k.head())
                    logging.info("New Latest TimeStamp " + str(df_k.TimeStamp.max()))
                    
                    if((df_k.TimeStamp.max() is pd.NaT) and (i>0)):
                        logging.info("NaT Found")
                        if (float(ingestion_lag)> float(12)):
                            current_latest_date = str(catchup_interval)
                            update_latest_dateTime(cursor, cnxn,catchup_interval, site_id)
                            time.sleep(10)
                        i-=1
                        continue
                    # logging.info(alarms_configuration)
                    set_alarm_dict(alarm_config_list=alarms_configuration)
                    # df_with_alarams= df
                    df_with_alarams= pd.DataFrame()
                    for tagName in range(0,len(alarms_configuration)):
                        temp_df,populate_db = detectChange(cursor, cnxn,df_k,alarms_configuration[tagName][0],
                        alarms_configuration[tagName][1],alarms_configuration[tagName][2],alarms_configuration[tagName][3],
                        alarms_configuration[tagName][4],alarms_configuration[tagName][5],alarms_configuration[tagName][6],
                        alarms_configuration[tagName][7],df_latest_triggered_alarms)

                        if populate_db == True:
                            df_with_alarams=pd.concat([df_with_alarams,temp_df])
                            logging.info("df_with_alarams")
                            logging.info(df_with_alarams)
                            final_change_detected_df= df_with_alarams[
                            ['DataAlarmActionGUID','DataAlarm_ID','State_ID','AST_ID','Current_Value','Reading_Time','AlarmType','action_ID','IsActive']]
                            logging.info("******************final_change_detected_df if condition*********************")
                            logging.info(final_change_detected_df)
                            final_change_detected_df.dropna(subset = ["AlarmType"], inplace=True)
                            #df_all.dropna(inplace=True)
                            final_change_detected_df.reset_index(drop=True, inplace=True)
                            # final_change_detected_df = final_change_detected_df.reindex(
                            #     columns=['DataAlarmActionGUID','Current_Value','action_ID','IsActive','AlarmType','AST_ID'])
                            logging.info("*************FINAL CHANGE DETECTED DF RAW IF CONDITION*************")
                            logging.info(final_change_detected_df.head())

                            # alarms_configuration_sql= get_alarms_config(cnxn, site_id)
                            # eventhub_conn_string= alarms_configuration_sql['EventHub_ConnStr'][0]

                            # try:
                            #     Stage = "Data Alarms to Event Hub"
                            #     dataAlarm_to_eventhub(df,eventhub_conn_string)
                            # except:
                            #     TS = datetime.datetime.now(pytz.timezone('Asia/Karachi'))
                            #     Status = "Error"
                            #     #log_entry(cursor,cnxn,TS,site_id,Type,Status,Exec_ID,Stage=Stage,Error="No Event Hub found against this Site ID.")
                            #     logging.info(json.dumps({"ERROR":"Data Ingestion into eventhub Failed"}))

                            # try:
                            #     dataAlarm_to_sqlServer(df,cnxn,cursor)
                            # except:
                            #     Stage="Data Alarms to SQL"
                            #     TS = datetime.datetime.now(pytz.timezone('Asia/Karachi'))
                            #     Status = "Error"
                            #     # log_entry(cursor,cnxn,TS,site_id,Type,Status,Exec_ID,Stage=Stage,Error="No Event Hub found against this Site ID.")
                            #     logging.info(json.dumps({"ERROR":"Data Ingestion into sql Failed"}))

                        else:
                            logging.info("*********INSIDE PASS TYPE ELSE**********")
                            pass
                            # df_with_alarams=df_latest_triggered_alarms
                            # logging.info("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
                            # logging.info(df_with_alarams.index)
                            # #for ind in df_with_alarams.index:
                            # logging.info("@@@@@@@@@@@@@@@@ INSIDE QUERY LOOP @@@@@@@@@@@@@@@@@@@@@@@")
                            # col_names = ','.join(str(v) for v in df_latest_triggered_alarms['DataAlarm_ID'].tolist())

                            # query_other_columns = 'select DataAlarmActionGUID,AST_ID,Current_Value,IsActive from DATA_ALARM_ACTION where dataalarm_id IN ({col_names})'.format(col_names=col_names)   #format(df_latest_triggered_alarms['DataAlarm_ID'].tolist())
                            # logging.info("*******************EACH COLUMN VALUE******************")
                            # logging.info(query_other_columns)
                            # df_with_alarams.append(pd.read_sql(query_other_columns,cnxn))

                            
                            # final_change_detected_df= df_with_alarams[['DataAlarmActionGUID','DataAlarm_ID','State_ID','AST_ID','Current_Value','Reading_Time','AlarmType','action_ID','IsActive']]
                            # logging.info("******************final_change_detected_df else condition*********************")
                            # logging.info(final_change_detected_df.head())
                            # final_change_detected_df.dropna(subset = ["AlarmType"], inplace=True)
                            
                        
                            # #df_all.dropna(inplace=True)
                            # final_change_detected_df.reset_index(drop=True, inplace=True)
                            # final_change_detected_df = final_change_detected_df.reindex(
                            #     columns=['DataAlarmActionGUID','Current_Value','action_ID','IsActive','AlarmType','AST_ID'])
                            
                            # logging.info("*************FINAL CHANGE DETECTED DF RAW ELSE CONDITION*************")
                            # logging.info(final_change_detected_df.head())

                            

                    # df_with_alarams.to_csv("final_alarms_df_raw.csv")
                    # TODO:fix calc and raw dataframe mutually exlusiveness
                    final_change_detected_df = pd.DataFrame()
                    if not df_with_alarams.empty:
                        final_change_detected_df= df_with_alarams[
                            ['DataAlarmActionGUID','DataAlarm_ID','State_ID','AST_ID','Current_Value','Reading_Time','AlarmType','action_ID','IsActive']]
                        logging.info("******************final_change_detected_df*********************")
                        logging.info(final_change_detected_df.head())
                        final_change_detected_df.dropna(subset = ["AlarmType"], inplace=True)
                    
                        #df_all.dropna(inplace=True)
                        final_change_detected_df.reset_index(drop=True, inplace=True)
                        # final_change_detected_df = final_change_detected_df.reindex(
                        #     columns=['DataAlarmActionGUID','Current_Value','action_ID','IsActive','AlarmType','AST_ID'])
                        
                        logging.info("*************FINAL CHANGE DETECTED DF RAW*************")
                        logging.info(final_change_detected_df.head())

                    if (not final_change_detected_df.empty) and (not final_change_detected_calc_df.empty):
                        logging.info("Both")
                        logging.info("****************BOTH DF RAW AND CALC*****************")
                        df  =  final_change_detected_df.append(final_change_detected_calc_df)
                        logging.info(df.head)
                        
                    elif (final_change_detected_calc_df.empty) and (not final_change_detected_df.empty):
                        logging.info("Raw only")
                        df  =  final_change_detected_df
                    elif (not final_change_detected_calc_df.empty) and (final_change_detected_df.empty):
                        logging.info("Calc only")
                        df  =  final_change_detected_calc_df
                    else:
                        logging.info("No alarm is triggered")
                        df = pd.DataFrame()

                    if not (df.empty):
                        #df['Reading_Time'] = df['Reading_Time'].dt.strftime('%Y-%m-%d %H:%M:%S.%f+00:00')
                        #df['Reading_Time'] = pd.to_datetime(df['Reading_Time'], errors='coerce')   
                        df['Reading_Time'] = pd.to_datetime(df.Reading_Time, format='%Y-%m-%d %H:%M:%S')
                        df['Reading_Time'] = df['Reading_Time'].dt.strftime('%Y-%m-%d %H:%M:%S') #2022-03-22 06:00:20 "%Y-%m-%d %H:%M:%S:%f"
                        logging.info("*******READING TIME******")
                        logging.info(df['Reading_Time'])
                        logging.info("*******READING TIME END******")
                        df= df.drop_duplicates(subset=['DataAlarm_ID','State_ID','AST_ID','Current_Value','Reading_Time','AlarmType','IsActive'])
                        #df.to_csv("final_alarms_df.csv")
                    
                        logging.info("Total df count or ingestion: " + str(df.shape[0]))
                    #   logging.info(df[['DataAlarm_ID','AST_ID','AlarmType']])
                                
                    # # # ----------------------- AZ CLI FOR EVENT HUB STRING FINISHED ---------------------------------

                    alarms_configuration_sql= get_alarms_config(cnxn, site_id)
                    eventhub_conn_string= alarms_configuration_sql['EventHub_ConnStr'][0]

                    try:
                        Stage = "Data Alarms to Event Hub"
                        dataAlarm_to_eventhub(df,eventhub_conn_string)
                    except:
                        TS = datetime.datetime.now(pytz.timezone('Asia/Karachi'))
                        Status = "Error"
                        #log_entry(cursor,cnxn,TS,site_id,Type,Status,Exec_ID,Stage=Stage,Error="No Event Hub found against this Site ID.")
                        logging.info(json.dumps({"ERROR":"Data Ingestion into eventhub Failed"}))

                    # # ----------------------- Ingest Data into EventHub Finished ---------------------------------
                
                    # # ----------------------- Ingest Data into Sql server ---------------------------------
                    try:
                        dataAlarm_to_sqlServer(df,cnxn,cursor)
                    except:
                        Stage="Data Alarms to SQL"
                        TS = datetime.datetime.now(pytz.timezone('Asia/Karachi'))
                        Status = "Error"
                        # log_entry(cursor,cnxn,TS,site_id,Type,Status,Exec_ID,Stage=Stage,Error="No Event Hub found against this Site ID.")
                        logging.info(json.dumps({"ERROR":"Data Ingestion into sql Failed"}))

                    # ----------------------- Ingest Data into Sql server Finished ---------------------------------
                    logging.info("*****DF_K******")
                    logging.info(df_k.head())
                    latest_current_time = df_k.TimeStamp.max().strftime('%Y-%m-%d %H:%M:%S')
                    logging.info("**********LATEST TIME**********".format(latest_current_time))
            
                
                
                if (float(ingestion_lag)<= float(12)):
                    update_latest_dateTime(cursor, cnxn,latest_current_time, site_id)
                elif (float(ingestion_lag)> float(12)):
                    update_latest_dateTime(cursor, cnxn,catchup_interval, site_id)

                if(df_k.TimeStamp.max() is not pd.NaT):
                    logging.info("BROKEN")
                    break        
            except Exception as e:
                logging.info(json.dumps({"exception":str(e)}))
                logging.info("BROKEN in exception")
                break

    logging.info("Function Finished Successfully")
 