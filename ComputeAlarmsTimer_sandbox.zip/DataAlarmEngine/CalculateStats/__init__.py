import datetime
from distutils.command import check
import logging
from typing import final
from azure.eventhub import EventData
from azure.kusto import data
from azure.kusto.data import KustoClient, KustoConnectionStringBuilder
from azure.kusto.data.helpers import dataframe_from_result_table
from azure.kusto.ingest import (
    QueuedIngestClient,
    IngestionProperties,
)
from azure.kusto.data import DataFormat
import json
import pandas as pd
from pandas.core.reshape.melt import melt
import pyodbc
import os
import sys
import azure.functions as func

from shared_code import statsalarms_utility #(absolute)

#ADX APP Credentials
AAD_TENANT_ID = '0f34cb0d-38ea-428d-8114-6486d17b9df5'
client_id = '1813de48-2733-4220-ab74-7804859f8fb6'
client_secret = 'cHi8Q~xFi3Sp2D6BvUFBV.Ybh_VJwwnQBe4tGaLg'
CALCULATED_TAG_TYPE = "Calculated"
RAW_TAG_TYPE = "Raw"

table_config = {CALCULATED_TAG_TYPE:{"table_name":"Calculated_Tags","id_col_name":"C_Tag_Id","id_mapped_name":"C_Tag_Name"},
RAW_TAG_TYPE:{"table_name":"Real_Raw_Points","id_col_name":"Real_Tag_Id","id_mapped_name":"R_Mapped_Name"}}

#Connect to Kusto Client
cluster = "https://sandboxadx.southeastasia.kusto.windows.net/"
ingest_cluster = "https://ingest-sandboxadx.southeastasia.kusto.windows.net"

kcsb = KustoConnectionStringBuilder.with_aad_application_key_authentication(cluster, client_id, client_secret, AAD_TENANT_ID)
kcsb_ingest = KustoConnectionStringBuilder.with_aad_application_key_authentication(ingest_cluster, client_id, client_secret, AAD_TENANT_ID)
kusto_client = KustoClient(kcsb)
kusto_ingestion_client = QueuedIngestClient(kcsb_ingest)

def get_site_name(cnxn, site_id):
    sql = "SELECT AutomationTableName FROM Plant_Site WHERE Site_Id = '"+str(site_id)+"'"
    temp_df = pd.read_sql(sql,cnxn)
    site_name = temp_df['AutomationTableName'][0]
    return site_name

def kusto_execute(db,query,kusto_client,return_df=False):
    response = kusto_client.execute(db, query)
    if return_df == True:
        return dataframe_from_result_table(response.primary_results[0])

def return_time_lag(database_name,tag_type,site_name):
    pass

def check_if_update_time(database_name,tag_type,site_name):
    if(tag_type==RAW_TAG_TYPE):
        table_name="Raw"
    else:
        table_name='Calc'

    query = f"""
    {table_name}_{site_name}
    | sort by TimeStamp desc 
    | take 1
    | project TimeStamp
    """
    logging.info(query)
    df = kusto_execute(database_name, query, kusto_client, return_df=True)
    latest_calc_ts = str(df['TimeStamp'][0].tz_localize(None))

    query = f"""
    Stats_{site_name}
    | where Tag_Type == '{tag_type}'
    | sort by TimeStamp desc 
    | take 1
    | project Data_Exists=iff(format_datetime(TimeStamp, 'yyyy-MM-dd') == format_datetime(datetime("""+latest_calc_ts+""")-1d, 'yyyy-MM-dd'), True, False)
    """
    logging.info(query)
    df = kusto_execute(database_name, query, kusto_client, return_df=True)
    return df

def check_day_lag(database_name,tag_type,site_name):
    if(tag_type==RAW_TAG_TYPE):
        table_name="Raw"
    else:
        table_name='Calc'

    query = f"""
    let date1 = toscalar({table_name}_{site_name} | summarize format_datetime(max(TimeStamp),"yyyy-MM-dd"));
    let date2 = toscalar(Stats_{site_name} | summarize format_datetime(max(TimeStamp),"yyyy-MM-dd"));
    print
    day = datetime_diff('day',todatetime(date1),todatetime(date2))
    """
    logging.info(query)
    df = kusto_execute(database_name, query, kusto_client, return_df=True)
    day_lag = str(df['day'][0])
    
    if( (isinstance(day_lag, str)) & (day_lag == "None")):
        day_lag = 2

    return int(day_lag) - 1

def check_if_month_update(database_name,tag_type,site_name):
    if(tag_type==RAW_TAG_TYPE):
        table_name="Raw"
    else:
        table_name='Calc'

    query = f"""
    {table_name}_{site_name}
    | sort by TimeStamp desc 
    | take 1
    | project TimeStamp
    """
    df = kusto_execute(database_name, query, kusto_client, return_df=True)
    latest_calc_ts = df['TimeStamp'][0].tz_localize(None)


    query = f"""
    Stats_{site_name}
    | where Tag_Type == '{tag_type}'
    | sort by TimeStamp desc 
    | take 1
    """
    df = kusto_execute(database_name, query, kusto_client, return_df=True)
    latest_calc_stats_ts = df['TimeStamp'][0].tz_localize(None)


    if latest_calc_stats_ts.month == latest_calc_ts.month:
        return True
    else:
        return False

def get_statistical_tags(cnxn,site_id,table_type,config):
    #Get configured calc stats tags in OmniConnect
    
    table_name = config['table_name']
    tag_id_col = config['id_col_name']
    tag_mapped_col = config['id_mapped_name']
    
    sql = f"""
    SELECT *
    FROM {table_name}
    WHERE Site_Id_FK = {site_id} AND
    StatisticalRefrenceId IS NOT NULL
    """
    temp_df = pd.read_sql(sql,cnxn)

    list_of_stat_tags = list(map(str,temp_df['StatisticalRefrenceId']))
    logging.info("**LIST OF STATS TAG**")
    logging.info(list_of_stat_tags)
    statistical_tags = []

    if (len(list_of_stat_tags) > 0): # if calculated tags are configured
        sql = f"""SELECT *
        FROM {table_name}
        WHERE Site_Id_FK = {site_id} AND
        {tag_id_col} IN (""" + ','.join(list_of_stat_tags) + """)"""
        temp_df = pd.read_sql(sql,cnxn)

        statistical_tags = list(temp_df[tag_mapped_col])

    logging.info("**********TEMP DF, STATS TAGS**************")
    return temp_df,statistical_tags

def get_calc_statistical_tags(cnxn,database_name,site_id):
    #Get configured calc stats tags in OmniConnect
    sql = f"""
    SELECT *
    FROM Calculated_Tags
    WHERE Site_Id_FK = {site_id} AND
    StatisticalRefrenceId IS NOT NULL
    """
    temp_df = pd.read_sql(sql,cnxn)

    list_of_stat_tags = list(map(str,temp_df['StatisticalRefrenceId']))
    statistical_tags = []

    if (len(list_of_stat_tags) > 0): # if calculated tags are configured
        sql = f"""SELECT *
        FROM Calculated_Tags
        WHERE Site_Id_FK = {site_id} AND
        c IN (""" + ','.join(list_of_stat_tags) + """)"""
        temp_df = pd.read_sql(sql,cnxn)

        statistical_tags = list(temp_df['C_Tag_Name'])    

    return statistical_tags

def get_raw_statistical_tags(cnxn,database_name,site_id):
    #Get configured calc stats tags in OmniConnect
    sql = f"""
    SELECT *
    FROM Real_Raw_Points
    WHERE Site_Id_FK = {site_id} AND
    StatisticalRefrenceId IS NOT NULL
    """
    temp_df = pd.read_sql(sql,cnxn)

    list_of_stat_tags = list(map(str,temp_df['StatisticalRefrenceId']))
    statistical_tags = []

    if (len(list_of_stat_tags) > 0): # if calculated tags are configured
        sql = f"""SELECT *
        FROM Real_Raw_Points
        WHERE Site_Id_FK = {site_id} AND
        Real_Tag_Id IN (""" + ','.join(list_of_stat_tags) + """)"""
        temp_df = pd.read_sql(sql,cnxn)

        statistical_tags = list(temp_df['R_Mapped_Name'])

    return statistical_tags


def get_project_query(site_name,temp_df,day_lag):
    list_of_devices = list(temp_df['Site_Specific_Device_Id'].unique())
    
    ingestion_table = "Raw_"+site_name


    raw_tags_dict = {}
    for x in list_of_devices:
        temp_df2 = temp_df.loc[temp_df['Site_Specific_Device_Id'] == x]
        raw_tags_dict[x] = dict(zip(list(temp_df2['R_Mapped_Name']),['R' + element for element in map(str,list(temp_df2['R_Mapped_By_Device']))]))


    # list_of_devices = list(temp_df['Site_Specific_Device_Id'].unique())
#     list_of_devices = list(raw_tags_dict.keys())
    num_of_devices = len(list_of_devices)
    if len(list_of_devices) > 1:
        join_check = True
    else:
        join_check = False
    close_join = False


    self_join_query = ""
    for x in list_of_devices:
        self_join_query += ingestion_table + "\n| where ID == " +str(x)+ f" and TimeStamp between(startofday(now(-{day_lag}d))..endofday(now(-1d)))"
        project = "| project TimeStamp = todatetime(format_datetime(TimeStamp,'yyyy-MM-dd HH:mm:ss')) , "
        for y in raw_tags_dict[x]:
            project +=  y +"="+raw_tags_dict[x][y] + ","

        project = project[:-1]
        self_join_query += project + "\n" 

        if close_join == True:
            self_join_query += ") on $left.TimeStamp == $right.TimeStamp\n"
            if num_of_devices <= 1:
                join_check = False
        if join_check == True:
            self_join_query += "| join kind=leftouter (" + "\n"
            close_join = True

        num_of_devices -= 1


    return self_join_query + "\n| sort by TimeStamp desc \n| summarize "



def get_statistical_data(tags,database_name,month_check,site_name,table_type,day_lag,temp_df):
    generic_query = None
    data_df = pd.DataFrame()

    if(table_type==CALCULATED_TAG_TYPE):
        table_identifier = "Calc"
        generic_query = f"""
        {table_identifier}_{site_name}
        | where TimeStamp between(startofday(now(-{day_lag}d))..endofday(now(-1d)))
        | sort by TimeStamp desc 
        | summarize """
        logging.info("*****GENERIC QUERY CALC TABALE*********")
        logging.inof(generic_query)
    else:
        table_identifier = "Raw"
        generic_query = get_project_query(site_name,temp_df,day_lag)
        logging.info("*****GENERIC QUERY RAW TABALE*********")
        logging.info(generic_query)

    for x in tags:
        generic_query += str(x) + "=series_stats_dynamic(make_list(" + str(x) + "), True),"
    
    logging.info("**********GENERIC QUERY AFTER LOOP************")
    logging.info(generic_query)
    # Day Average
    query = generic_query[:-1]
    query += " by bin(TimeStamp,1d)"
    query += "\n| extend Aggregation_resolution='day', Aggregation_value=1"
    logging.info("**************QUERY DAY AVE******************")
    logging.info(query)
    
    # logging.info(query)

    temp_df = kusto_execute(database_name, query, kusto_client, return_df=True)
    data_df = data_df.append(temp_df, ignore_index=True)


    # Hours Averages
    avgs_list = [2,4,8,12]
    
    for x in avgs_list:
        query = generic_query[:-1]
        query += " by bin(TimeStamp," + str(x) + "h)"
        query += "\n| extend Aggregation_resolution='hour', Aggregation_value=" + str(x)
        logging.info("*******AVG HOURLY QUERY*********")
        logging.info(query)
        temp_df = kusto_execute(database_name, query, kusto_client, return_df=True)
        data_df = data_df.append(temp_df, ignore_index=True)
    
    if month_check == False:
        # Month Average
        query = generic_query[:-1]
#         query += " by bin(TimeStamp,1d)"
        query += "\n| extend Aggregation_resolution='month', Aggregation_value=1"
        
        # print("Month Query",query)

        temp_df = kusto_execute(database_name, query, kusto_client, return_df=True)
        data_df = data_df.append(temp_df, ignore_index=True)

    melted = pd.melt(data_df, id_vars=['TimeStamp','Aggregation_resolution','Aggregation_value'], value_vars=tags)    
    melted = melted.dropna()
    logging.info("*********MELTED********")
    logging.info(melted)
    normalized = pd.concat([melted.drop('value', axis=1).reset_index(drop=True), pd.DataFrame(melted['value'].tolist()).reset_index(drop=True)], axis=1)
    logging.info("*********NORMALIZED********")
    logging.info(normalized)

    if(normalized.shape[0]>0):
        normalized = normalized[['TimeStamp','Aggregation_resolution','Aggregation_value','variable','min','max','avg','stdev','variance']]
        normalized = normalized.rename(columns={'variable': 'Tag_Name', 'variance': 'var'})
        normalized['Tag_Type'] = table_type
    else:
        return None
    # normalized.to_csv('fully_normalized.csv')
    return normalized

def get_calc_statistical_data(tags,database_name,month_check,site_name):
    data_df = pd.DataFrame()
    
    generic_query = f"""
    Calc_{site_name}
    | where TimeStamp between(startofday(now(-1d))..endofday(now(-1d)))
    | sort by TimeStamp desc 
    | summarize """

    for x in tags:
        generic_query += str(x) + "=series_stats_dynamic(make_list(" + str(x) + "), True),"
    
    # Day Average
    query = generic_query[:-1]
    query += " by bin(TimeStamp,1d)"
    query += "\n| extend Aggregation_resolution='day', Aggregation_value=1"
    
    # logging.info(query)

    temp_df = kusto_execute(database_name, query, kusto_client, return_df=True)
    data_df = data_df.append(temp_df, ignore_index=True)


    # Hours Averages
    avgs_list = [2,4,8,12]
    
    for x in avgs_list:
        query = generic_query[:-1]
        query += " by bin(TimeStamp," + str(x) + "h)"
        query += "\n| extend Aggregation_resolution='hour', Aggregation_value=" + str(x)
        
        temp_df = kusto_execute(database_name, query, kusto_client, return_df=True)
        data_df = data_df.append(temp_df, ignore_index=True)
    
    if month_check == False:
        # Month Average
        query = generic_query[:-1]
#         query += " by bin(TimeStamp,1d)"
        query += "\n| extend Aggregation_resolution='month', Aggregation_value=1"
        
        # print("Month Query",query)

        temp_df = kusto_execute(database_name, query, kusto_client, return_df=True)
        data_df = data_df.append(temp_df, ignore_index=True)

    melted = pd.melt(data_df, id_vars=['TimeStamp','Aggregation_resolution','Aggregation_value'], value_vars=tags)    
    melted = melted.dropna()
    normalized = pd.concat([melted.drop('value', axis=1).reset_index(drop=True), pd.DataFrame(melted['value'].tolist()).reset_index(drop=True)], axis=1)
    
    if(normalized.shape[0]>0):
        normalized = normalized[['TimeStamp','Aggregation_resolution','Aggregation_value','variable','min','max','avg','stdev','variance']]
        normalized = normalized.rename(columns={'variable': 'Tag_Name', 'variance': 'var'})
        normalized['Tag_Type'] = CALCULATED_TAG_TYPE
    else:
        return None
    # normalized.to_csv('fully_normalized.csv')
    return normalized

def get_raw_statistical_data(tags,database_name,month_check,site_name):
    data_df = pd.DataFrame()
    
    generic_query = f"""
    Raw_{site_name}
    | where TimeStamp between(startofday(now(-1d))..endofday(now(-1d)))
    | sort by TimeStamp desc 
    | summarize """

    for x in tags:
        generic_query += str(x) + "=series_stats_dynamic(make_list(" + str(x) + "), True),"
    
    # Day Average
    query = generic_query[:-1]
    query += " by bin(TimeStamp,1d)"
    query += "\n| extend Aggregation_resolution='day', Aggregation_value=1"
    
    # logging.info(query)

    temp_df = kusto_execute(database_name, query, kusto_client, return_df=True)
    data_df = data_df.append(temp_df, ignore_index=True)


    # Hours Averages
    avgs_list = [2,4,8,12]
    
    for x in avgs_list:
        query = generic_query[:-1]
        query += " by bin(TimeStamp," + str(x) + "h)"
        query += "\n| extend Aggregation_resolution='hour', Aggregation_value=" + str(x)
        
        temp_df = kusto_execute(database_name, query, kusto_client, return_df=True)
        data_df = data_df.append(temp_df, ignore_index=True)
    logging.info(query)
    if month_check == False:
        # Month Average
        query = generic_query[:-1]
#         query += " by bin(TimeStamp,1d)"
        query += "\n| extend Aggregation_resolution='month', Aggregation_value=1"
        
        # print("Month Query",query)

        temp_df = kusto_execute(database_name, query, kusto_client, return_df=True)
        data_df = data_df.append(temp_df, ignore_index=True)

    melted = pd.melt(data_df, id_vars=['TimeStamp','Aggregation_resolution','Aggregation_value'], value_vars=tags)    
    melted = melted.dropna()
    normalized = pd.concat([melted.drop('value', axis=1).reset_index(drop=True), pd.DataFrame(melted['value'].tolist()).reset_index(drop=True)], axis=1)

    if(normalized.shape[0]>0):
        normalized = normalized[['TimeStamp','Aggregation_resolution','Aggregation_value','variable','min','max','avg','stdev','variance']]
        normalized = normalized.rename(columns={'variable': 'Tag_Name', 'variance': 'var'})
        normalized['Tag_Type'] = RAW_TAG_TYPE
    else:
        return None
    # normalized.to_csv('fully_normalized.csv')
    return normalized


def ingest_into_kusto(df,site_name,kusto_ingestion_client):
    ##################
    ### INGESTION ###
    ##################

    ingestion_props = IngestionProperties(
        database=site_name,
        table="Stats_" + site_name,
        data_format=DataFormat.CSV,
        # in case status update for success are also required
        # report_level=ReportLevel.FailuresAndSuccesses,
        # in case a mapping is required
        # ingestion_mapping_reference="{json_mapping_that_already_exists_on_table}"
        # ingestion_mapping_type=IngestionMappingType.JSON
    )

    kusto_ingestion_client.ingest_from_dataframe(df, ingestion_properties=ingestion_props)

def main(mytimer: func.TimerRequest) -> None:
    logging.info("Http function execution started")
    final_df = pd.DataFrame()
    
    
    site_id         = os.environ["site_id"]
    database_name   = os.environ["database_name"]
    #Connect to SQL
    server ='tcp:octopusdigitalsql.database.windows.net'
    database = database_name
    username = 'octopusdigital' 
    password = os.environ["Database_Key"]

    cnxn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)
    # cursor = cnxn.cursor()
    site_name = get_site_name(cnxn,site_id)
    database_name = site_name

    final_df = pd.DataFrame()
    for key,value in table_config.items():
        table_type = key
        config = value
        d1 = check_if_update_time(database_name,table_type,site_name)
        logging.info("***************D1***********")
        logging.info(d1)
        
        day_lag = check_day_lag(database_name,table_type,site_name)
        logging.info("***********DAY LAG**************")
        logging.info(day_lag)
        # day_lag = 6
        if(day_lag>=1):
            calc_data_df =  pd.DataFrame()
            
            if len(d1) == 0:
                logging.info(key+" first")
                        
                # getting stats data for calc table
                temp_df,tags = get_statistical_tags(cnxn,site_id,table_type,config)
                logging.info("********STATS TAG*************")
                logging.info(tags)

                if(len(tags) > 0):
                    month_check = True
                    calc_data_df = get_statistical_data(tags,database_name,month_check,site_name,table_type,day_lag,temp_df)

                    log_string = 'FIRST TIME Appended Hour and Day Averages for ' + database_name
                    logging.info(log_string)
                else:
                    logging.info(f"No Tags are configured for {table_type} table")
            else:
                if d1['Data_Exists'][0] == False:
                    logging.info(key+" second")

                    # getting stats data for calc table
                    temp_df,tags = get_statistical_tags(cnxn,site_id,table_type,config)

                    if(len(tags) > 0):
                        month_check = check_if_month_update(database_name,table_type,site_name)
                        logging.info("***************MONTH CHECK************")
                        logging.info(month_check)
                        calc_data_df = get_statistical_data(tags,database_name,month_check,site_name,table_type,day_lag,temp_df)
                        logging.info("***************CALC DATA DF************")
                        logging.info(calc_data_df)

                        log_string = 'Appended Hour and Day Averages for ' + database_name
                        logging.info(log_string)
                    else:
                        logging.info(f"No Tags are configured for {table_type} table")
                else:
                    log_string = 'No new data for ' + database_name
                    logging.info(log_string)
                    pass 
            
            final_df = pd.concat([final_df,calc_data_df])

            if not final_df.empty:
                logging.info("Rows in Statistical frame: " + str(final_df.shape[0]))
                logging.info("Ingesting Stats calculations into ADX")
                for _ in range(3):
                    try:
                        ingest_into_kusto(final_df,site_name=site_name,kusto_ingestion_client=kusto_ingestion_client)
                        logging.info("Ingestion into ADX Successfull!")
                        break
                    except Exception as e:
                        logging.info(str(e))

                logging.info("Calculating Stats Alarms into ADX")
                statsalarms_utility.stats_alarms(final_df, cnxn, site_id)
            else:
                logging.info("Empty Tables!")
            # logging.info('Python timer trigger function ran at %s', utc_timestamp)
        else:
            logging.info(f"No New Data Found for {table_type}")
        
    logging.info("Statistical function done")
    
