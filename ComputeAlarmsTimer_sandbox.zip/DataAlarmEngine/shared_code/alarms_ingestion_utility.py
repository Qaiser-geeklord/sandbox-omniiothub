from azure.eventhub import EventHubProducerClient
from azure.eventhub import EventData
import pandas as pd
import logging
import datetime
import pytz

def dataAlarm_to_eventhub(df,conn_str):
    CONNECTION_STR = conn_str
    EVENTHUB_NAME = "dataalarms"

    df.dropna(subset = ["Reading_Time"], inplace=True)
    df = df.drop('AS_Id', axis=1)

    df.reset_index(drop=True,inplace=True)
    # logging.info(df[['']])
    
    # Without specifying partition_id or partition_key
    # the events will be distributed to available partitions via round-robin.
    try:
        producer = EventHubProducerClient.from_connection_string(conn_str=CONNECTION_STR,eventhub_name=EVENTHUB_NAME)
    except Exception as e:
        logging.info(str(e))

    try:
        with producer:
            # send_event_data_batch(producer)
        
            event_data_batch = producer.create_batch()
            logging.info("Sending Data to Eventhub")
            for i in df.index:
                json_string = df.loc[i].to_json()
                event_data_batch.add(EventData(json_string))
                # logging.info(json_string)
            producer.send_batch(event_data_batch)
    except Exception as e:
        logging.info(str(e))
    logging.info("Data sent to eventhub!")

def get_alarms_config(cnxn, siteId):
    sql = f"""select SITE_ID, CURRENT_LATEST_DATETIME,EventHub_ConnStr FROM DATA_ALARMS_CONFIG where SITE_ID={siteId}"""
    temp_df = pd.read_sql(sql,cnxn)
    return temp_df

def dataAlarm_to_sqlServer(df,cnxn):
    df = df[['DataAlarmActionGUID','DataAlarm_ID','State_ID','AST_ID','Current_Value','Reading_Time','AS_Id']]
    # df['Reading_Time'] = pd.to_datetime(df.Reading_Time)
    df.dropna(subset = ["Reading_Time"], inplace=True)

    df['Reading_Time'] = df['Reading_Time'].dt.strftime('%Y%m%d %H:%M:%S')
    df = df[df['AS_Id'] != 3]


    df["AST_ID"].fillna("Null", inplace = True)
    cursor = cnxn.cursor()
    # creating column list for insertion
    # cols = "`,`".join([str(i) for i in df.columns.tolist()])
    # Insert DataFrame recrds one by one.
    try:
        # Insert Dataframe into SQL Server:
        for index, row in df.iterrows():
            sql = f"INSERT INTO DATA_ALARM_ACTION (DataAlarmActionGUID,DataAlarm_ID,State_ID,AST_ID,Current_Value,Reading_Time,AS_Id,isActive) values ('{row.DataAlarmActionGUID}',{row.DataAlarm_ID},{row.State_ID}, {row.AST_ID},{row.Current_Value},CAST(N'{row.Reading_Time}' AS DateTime),2,1)"
            # print(sql)
            cursor.execute(sql)
        # logging.info("HERE")
        # logging.info(sql)
        cnxn.commit()
        logging.info("Data ingested into SQL")
    except Exception as e:
        logging.info(str(e))
        raise Exception("Loading into SQL Failed.")
    # the connection is not autocommitted by default, so we must commit to save our changes
    logging.info("Data sent to SQL!")

def main(df,cnxn,site_id):

    alarms_configuration_sql= get_alarms_config(cnxn, site_id)
    eventhub_conn_string= alarms_configuration_sql['EventHub_ConnStr'][0]

# # # ----------------------- Ingest Data into EventHub ---------------------------------
    logging.info("Sending data to EventHub")

    try:
        dataAlarm_to_eventhub(df,eventhub_conn_string)
    except Exception as e:
        logging.info(str(e))
# # ----------------------- Ingest Data into Sql server ---------------------------------
    logging.info("Sending data to SQL")

    try:
        dataAlarm_to_sqlServer(df,cnxn)
    except Exception as e:
        logging.info(str(e))
