from shared_code import alarms_ingestion_utility
import pandas as pd
import logging
import datetime
import pytz
import uuid

def get_stats_alarms(cnxn, site_id):
    sql = f"""select dc.AST_ID,rt.R_Mapped_Name,ds.State_Title,d.DataAlarm_ID,dc.UpperValue,dc.LowerValue,dc.isAlarmOn, dc.State_ID,dc.AS_Id from DATA_ALARM_STATES_CONFIG dc 
            inner join DATA_ALARM d 
            on dc.DataAlarm_ID=d.DataAlarm_ID
            inner join DATA_ALARM_STATES ds
            on dc.State_ID=ds.State_ID
            inner join Real_Raw_Points rt
            on d.Real_Tag_Id=rt.Real_Tag_Id
            where rt.Site_Id_FK={site_id} and isAlarmOn=1 and State_Title in ('Variance','Maximum','Minimum','Average','Standard Deviation')
            UNION
            select dc.AST_ID,ct.C_Tag_Name as Tag_Name,ds.State_Title,d.DataAlarm_ID,dc.UpperValue,dc.LowerValue,dc.isAlarmOn, dc.State_ID,dc.AS_Id from DATA_ALARM_STATES_CONFIG dc 
            inner join DATA_ALARM d 
            on dc.DataAlarm_ID=d.DataAlarm_ID
            inner join DATA_ALARM_STATES ds
            on dc.State_ID=ds.State_ID
            inner join Calculated_Tags ct
            on d.C_Tag_Id=ct.C_Tag_Id
            where ct.Site_Id_FK={site_id} and isAlarmOn=1 and State_Title in ('Variance','Maximum','Minimum','Average','Standard Deviation')"""

    temp_df = pd.read_sql(sql,cnxn)
    return temp_df

def detectChange_stats(df,tagAstID,_tagDataAlarmID,tagName,_upperValue,_lowerValue, _alarmState, _stateID,_ASId):
    tagAST_ID               =   tagAstID
    tagDataAlarmID          =   _tagDataAlarmID
    _df                     =   df.copy()
    currentTag              =   tagName
    upperValue              =   _upperValue
    lowerValue              =   _lowerValue
    alarmState              =   _alarmState
    stateID                 =   _stateID
    AS_Id                   = _ASId

    states_dict =	{
    "Average": "avg",
    "Maximum": "max",
    "Minimum": "min",
    "Variance": "var",
    "Standard Deviation":"stdev"
    }

    df_col=''

    tag_exists  =   _df.loc[_df['Tag_Name'] == currentTag]
    

    if len(tag_exists) >0:
        _df =   df[df['Tag_Name']==currentTag]
        if (alarmState == 'Average'):
            df_col=states_dict[alarmState]
        elif (alarmState == 'Maximum'):
            df_col=states_dict[alarmState]
        elif (alarmState == 'Minimum'):
            df_col=states_dict[alarmState]
        elif (alarmState == 'Variance'):
            df_col=states_dict[alarmState]
        elif (alarmState == 'Standard Deviation'): 
            df_col=states_dict[alarmState]

        if len(_df)!=0:
            # currentVal_outRange       =((_df[df_col] <= upperValue) & (_df[df_col] >= lowerValue))
            # nextVal_condition        =  ((_df[df_col].shift(periods=-1) < lowerValue) | (_df[df_col].shift(periods=-1) > upperValue))
            #
            # _df['changeDetected']           =    (currentVal_outRange & nextVal_condition).shift(periods=1)
            _df['changeDetected'] = ((_df[df_col] < lowerValue) | (_df[df_col] > upperValue))
            _df.loc[(_df['changeDetected'] == True), 'DataAlarm_ID']      = tagDataAlarmID
            _df.loc[(_df['changeDetected'] == True), 'AST_ID']            = tagAST_ID
            _df.loc[(_df['changeDetected'] == True), 'Current_Value']     = _df[df_col]
            _df.loc[(_df['changeDetected'] == True), 'Reading_Time']      =_df['TimeStamp']
            _df.loc[(_df['changeDetected'] == True), 'TAGNAME']           = currentTag
            _df.loc[(_df['changeDetected'] == True), 'State_ID']          = stateID #states_dict[alarmState]
            _df.loc[(_df['changeDetected'] == True), 'AS_Id']          = AS_Id #states_dict[alarmState]
            
            _df['alarmDisabled'] = ((_df[df_col] > lowerValue) & (_df[df_col] < upperValue))
            _df.loc[(_df['alarmDisabled'] == True), 'alarmDisabled_State']  = alarmState
            _df.loc[(_df['alarmDisabled'] == True), 'tmpAST_ID']            = tagAST_ID
            _df.loc[(_df['alarmDisabled'] == True), 'tmpCurrent_Value']     = _df[df_col]
            _df.loc[(_df['alarmDisabled'] == True), 'tmpReading_Time']      = _df['TimeStamp']
            _df.loc[(_df['alarmDisabled'] == True), 'tmpDataAlarm_ID']      = tagDataAlarmID
            _df.loc[(_df['alarmDisabled'] == True), 'tmpState_ID']          = stateID
        else:
            logging.info("Found no dataframe for detecting statistical alarms in utility")

    else:
        logging.info(currentTag + " data does not exist in dataframe")

    df2 = _df[["tmpDataAlarm_ID", "tmpAST_ID","tmpReading_Time","tmpState_ID"]].copy()
    df2=df2.rename(columns={'tmpAST_ID': 'AST_ID', 'tmpReading_Time': 'Reading_Time','tmpDataAlarm_ID': 'DataAlarm_ID','tmpState_ID':'State_ID'})
    df2 = df2.dropna()
    _df['IsActive']    =   1
    df2['IsActive']   =   0
    final_df = pd.concat([_df,df2], ignore_index=True)
    final_df['DataAlarmActionGUID']   = [str(uuid.uuid4()) for x in range(len(final_df))]
    final_df['AlarmType']         = 'Statistical_Alarm'
    
    return final_df


def stats_alarms(_df,cnxn, site_id):
    stats_alarms_configuration_DF        =   get_stats_alarms(cnxn,site_id)
    stats_alarms_configuration_DF        =   stats_alarms_configuration_DF[['AST_ID','DataAlarm_ID','R_Mapped_Name', 'UpperValue','LowerValue','State_Title','State_ID','AS_Id']]
    stats_alarms_configuration_List      =   stats_alarms_configuration_DF.values.tolist()
    stats_tags_list                      =   list(set(stats_alarms_configuration_DF['R_Mapped_Name'].values.tolist()))
    stats_tags_list.sort()
    
    stats_df    = _df
    Aggregation_resolution               =   stats_df['Aggregation_resolution'] == 'hour'
    Aggregation_value                    =   stats_df['Aggregation_value'] == 2
    stats_df                             =   stats_df[Aggregation_resolution   &   Aggregation_value]
    stats_df                             =   stats_df[['TimeStamp','Tag_Name','min','max','avg','stdev','var']]
    stats_alarms_df                      =   pd.DataFrame(columns=['TimeStamp','Tag_Name','min','max','avg','stdev','var'])
    logging.info(stats_alarms_configuration_List)

    for tagName in range(0,len(stats_alarms_configuration_List)):
            stats_alarms_df=stats_alarms_df.append(detectChange_stats(stats_df,stats_alarms_configuration_List[tagName][0],stats_alarms_configuration_List[tagName][1],stats_alarms_configuration_List[tagName][2],stats_alarms_configuration_List[tagName][3],stats_alarms_configuration_List[tagName][4],stats_alarms_configuration_List[tagName][5],stats_alarms_configuration_List[tagName][6],stats_alarms_configuration_List[tagName][7]))

    stats_alarms_df    =   stats_alarms_df[['DataAlarmActionGUID','DataAlarm_ID','AST_ID','Current_Value','Reading_Time','AlarmType','State_ID','AS_Id','IsActive' ]]
    stats_alarms_df.dropna(subset=["Current_Value"], inplace=True)
    pd.set_option('display.max_columns', None)

    logging.info("Stats Alarms Count: "+str(stats_df.shape[0]))
    alarms_ingestion_utility.main(stats_alarms_df,cnxn,site_id)